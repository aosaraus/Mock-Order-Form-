/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author sarau
 */
public class OrderFormServlet extends HttpServlet {

 

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String errorMessage = "";
        String url = "";
        
        String product = request.getParameter("productName");
        request.setAttribute("productName", product);
         
        String quantity = request.getParameter("quantity");
        double quantityNum = Double.parseDouble(quantity);
        
        String price = request.getParameter("unitPrice");
        request.setAttribute("itemPrice", price);
        double priceNum = Double.parseDouble(price);
       
        
        double totalPrice = quantityNum * priceNum;
        totalPrice = Math.round(totalPrice * 100.0)/100.0;
        String total_Price = new Double(totalPrice).toString();
        request.setAttribute("price", total_Price);
        
        String name = request.getParameter("customerName");
        request.setAttribute("name", name);
        
        String address = request.getParameter("shippingAddress");
        request.setAttribute("address", address);
        
        String cardType = request.getParameter("card_type");
        request.setAttribute("cardType", cardType);
        
        String card1 = request.getParameter("credit_card1");
        String card2 = request.getParameter("credit_card2");
        
        if (!card1.equals(card2)){
            errorMessage = "Credit card numbers do not match";
            request.setAttribute("errorMessage", errorMessage);
            url = "/index.jsp";
            
        } else {
            url = "/display.jsp";
        }
        
       
        getServletContext()
            .getRequestDispatcher(url)
            .forward(request, response);
  
    }

    
 
    
}
